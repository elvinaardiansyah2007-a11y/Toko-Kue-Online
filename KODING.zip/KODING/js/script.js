let produkDipilih = "";

function bukaPembayaran(namaProduk) {
  produkDipilih = namaProduk;
  document.getElementById("popup").style.display = "flex";
}

function konfirmasiPembayaran() {
  const metode = document.getElementById("metode").value;
  alert(`Kamu membeli ${produkDipilih} dan memilih membayar dengan ${metode} 💖`);
  document.getElementById("popup").style.display = "none";
}

// Tutup opening saat diklik
document.getElementById("opening-screen").addEventListener("click", function () {
    this.style.display = "none";
});

// (OPSI) otomatis hilang setelah 1 detik
setTimeout(() => {
    const openscr = document.getElementById("opening-screen");
    if (openscr) openscr.style.display = "none";
}, 2500);

